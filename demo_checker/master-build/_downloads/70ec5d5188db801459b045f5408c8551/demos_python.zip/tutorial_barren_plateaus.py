r"""
.. _barren_plateaus:

Barren plateaus in quantum neural networks
==========================================

.. meta::
   :property="og:description": Showing how randomized quantum circuits face the problem of barren plateaus using PennyLane.
       We will partly reproduce some of the findings in McClean et. al., 2018 with just a few lines of code.
   :property="og:image": https://pennylane.ai/qml/_images/surface.png

.. related::

   tutorial_local_cost_functions Alleviating barren plateaus with local cost functions

*Author: Shahnawaz Ahmed — Posted: 11 October 2019. Last updated: 26 October 2020.*

In classical optimization, it is suggested that saddle
points, not local minima, provide a fundamental impediment
to rapid high-dimensional non-convex optimization
(Dauphin et al., 2014).

The problem of such barren plateaus manifests in a different
form in variational quantum circuits, which are at the heart
of techniques such as quantum neural networks or approximate
optimization e.g., QAOA (Quantum Adiabatic Optimization Algorithm)
which can be found in this `PennyLane QAOA tutorial
<https://pennylane.readthedocs.io/en/latest/tutorials/pennylane_run_qaoa_maxcut.html#qaoa-maxcut>`_.

While starting from a parameterized
random quantum circuit seems like a good unbiased choice if
we do not know the problem structure, McClean et al. (2018)
show that

*"for a wide class of reasonable parameterized quantum
circuits, the probability that the gradient along any
reasonable direction is non-zero to some fixed precision
is exponentially small as a function of the number
of qubits."*

Thus, randomly selected quantum circuits might not be the best
option to choose while implementing variational quantum
algorithms.


.. figure:: ../demonstrations/barren_plateaus/surface.png
   :width: 90%
   :align: center
   :alt: surface

|

In this tutorial, we will show how randomized quantum circuits
face the problem of barren plateaus using PennyLane. We will
partly reproduce some of the findings in McClean et. al., 2018
with just a few lines of code.

.. note::

    **An initialization strategy to tackle barren plateaus**

    How do we avoid the problem of barren plateaus?
    In Grant et al. (2019), the authors present one strategy to
    tackle the barren plateau problem in randomized quantum circuits:

    *"The technique involves randomly selecting some of the initial
    parameter values, then choosing the remaining values so that
    the final circuit is a sequence of shallow unitary blocks that
    each evaluates to the identity. Initializing in this way limits
    the effective depth of the circuits used to calculate the first
    parameter update so that they cannot be stuck in a barren plateau
    at the start of training."*

Exploring the barren plateau problem with PennyLane
---------------------------------------------------

First, we import PennyLane, NumPy, and Matplotlib
"""






##############################################################################
# Next, we create a randomized variational circuit

# Set a seed for reproducibility

































##############################################################################
# Now we can compute the gradient and calculate the variance.
# While we only sample 200 random circuits to allow the code
# to run in a reasonable amount of time, this can be
# increased for more accurate results. We only consider the
# gradient of the output with respect to the last parameter in the
# circuit. Hence we choose to save ``gradient[-1]`` only.





















##############################################################################
# Evaluate the gradient for more qubits
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# We can repeat the above analysis with increasing number of qubits.



























# Fit the semilog plot to a straight line



# Plot the straight line fit to the semilog








##############################################################################
# References
# ----------
#
# 1. Dauphin, Yann N., et al.,
#    Identifying and attacking the saddle point problem in high-dimensional non-convex
#    optimization. Advances in Neural Information Processing
#    systems (2014).
#
# 2. McClean, Jarrod R., et al.,
#    Barren plateaus in quantum neural network training landscapes.
#    Nature communications 9.1 (2018): 4812.
#
# 3. Grant, Edward, et al.
#    An initialization strategy for addressing barren plateaus in
#    parametrized quantum circuits. arXiv preprint arXiv:1903.05076 (2019).
#
#
# About the author
# ----------------
# .. include:: ../_static/authors/shahnawaz_ahmed.txt