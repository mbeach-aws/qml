r"""
.. _isingmodel_PyTorch:

3-qubit Ising model in PyTorch
==============================

.. meta::
    :property="og:description": This demonstration uses the PyTorch interface of
        PennyLane to optimize a 3-qubit Ising model.
    :property="og:image": https://pennylane.ai/qml/_images/isingspins.png

.. related::

   tutorial_state_preparation Training a quantum circuit with PyTorch
   pytorch_noise PyTorch and noisy devices

*Author: Aroosa Ijaz — Posted: 16 October 2019. Last updated: 26 October 2020.*

The interacting spins with variable coupling strengths of an `Ising model <https://en.wikipedia.org/wiki/Ising_model>`__
can be used to simulate various machine learning concepts like `Hopfield networks <https://en.wikipedia.org/wiki/Hopfield_network>`__
and `Boltzmann machines <https://en.wikipedia.org/wiki/Boltzmann_machine>`__
(`Schuld & Petruccione (2018) <https://www.springer.com/gp/book/9783319964232>`_).
They also closely imitate the underlying mathematics of a subclass of computational problems called
`Quadratic Unconstrained Binary Optimization (QUBO) <https://en.wikipedia.org/wiki/Quadratic_unconstrained_binary_optimization>`__ problems. 

Ising models are commonly encountered in the subject area of adiabatic quantum computing. Quantum annealing algorithms
(for example, as performed on a D-wave system) are often used to find low-energy configurations of Ising problems.
The optimization landscape of the Ising model is non-convex, which can make finding global minima challenging.
In this tutorial, we get a closer look at this phenomenon by applying gradient descent techniques to a toy Ising model. 

PennyLane implementation
------------------------

This basic tutorial optimizes a 3-qubit Ising model using the PennyLane ``default.qubit``
device with PyTorch. In the absence of external fields, the Hamiltonian for this system is given by:

.. math::  H=-\sum_{<i,j>} J_{ij} \sigma_i \sigma_{j},

where each spin can be in the +1 or -1 spin state and :math:`J_{ij}` are the nearest-neighbour coupling strengths.

For simplicity, the first spin can be assumed
to be in the "up" state (+1 eigenstate of Pauli-Z operator) and the coupling matrix can be set to :math:`J = [1,-1]`. The rotation angles for the other two spins are then optimized
so that the energy of the system is minimized for the given couplings.
"""






###############################################################################
# A three-qubit quantum circuit is initialized to represent the three spins:










###############################################################################
# The cost function to be minimized is defined as the energy of the spin configuration:









###############################################################################
# Sanity check
# ------------
# Let's test the functions above using the :math:`[s_1, s_2, s_3] = [1, -1, -1]` spin
# configuration and the given coupling matrix. The total energy for this Ising model
# should be:
#
# .. math:: H = -1(J_1 s_1 \otimes s_2 + J_2 s_2 \otimes s3) = 2 
#







###############################################################################
# Random initialization
# ---------------------














###############################################################################
# Optimization
# ------------
# Now we use the PyTorch gradient descent optimizer to minimize the cost:




























###############################################################################
#
# .. note::
#     When using the *PyTorch* optimizer, keep in mind that:
#
#     1. ``loss.backward()`` computes the gradient of the cost function with respect to all parameters with ``requires_grad=True``. 
#     2. ``opt.step()`` performs the parameter update based on this *current* gradient and the learning rate. 
#     3. ``opt.zero_grad()`` sets all the gradients back to zero. It's important to call this before ``loss.backward()`` to avoid the accumulation of gradients from multiple passes.
#
#     Hence, its standard practice to define the ``closure()`` function that clears up the old gradient, 
#     evaluates the new gradient and passes it onto the optimizer in each step. 
#
# The minimum energy is -2 for the spin configuration :math:`[s_1, s_2, s_3] = [1, 1, -1]`
# which corresponds to
# :math:`(\phi, \theta, \omega) = (0, 0, 0)` for the second spin and :math:`(\phi, \theta, \omega) = (0, \pi, 0)` for 
# the third spin. Note that gradient descent optimization might not find this global minimum due to the non-convex cost function, as is shown in the next section.








###############################################################################






# Enable processing the Torch trainable tensors







###############################################################################
# Local minimum
# -------------
# If the spins are initialized close to the local minimum of zero energy, the optimizer is
# likely to get stuck here and never find the global minimum at -2. 












###############################################################################

























###############################################################################



# Enable processing the Torch trainable tensors







###############################################################################
# |
#
# Try it yourself! Download and run this file with different
# initialization parameters and see how the results change.
#
# Further reading
# ---------------
#
# 1. Maria Schuld and Francesco Petruccione. "Supervised Learning with Quantum Computers."
# Springer, 2018.
#
# 2. Andrew Lucas. "Ising formulations of many NP problems."
# `arXiv:1302.5843 <https://arxiv.org/pdf/1302.5843>`__, 2014.
#
# 3. Gary Kochenberger et al. "The Unconstrained Binary Quadratic Programming Problem: A Survey."
# `Journal of Combinatorial Optimization <https://link.springer.com/article/10.1007/s10878-014-9734-0>`__, 2014.
#
#
# About the author
# ----------------
# .. include:: ../_static/authors/aroosa_ijaz.txt
