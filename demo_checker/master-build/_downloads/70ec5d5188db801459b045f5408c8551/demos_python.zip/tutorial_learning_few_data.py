r"""
.. _learning_few_data:

Generalization in QML from few training data
============================================

.. meta::
    :property="og:description": Generalization of quantum machine learning models.
    :property="og:image": https://pennylane.ai/qml/_images/few_data_thumbnail.png

.. related::

    tutorial_local_cost_functions Alleviating barren plateaus with local cost functions

*Authors: Korbinian Kottmann, Luis Mantilla Calderon, Maurice Weber — Posted: 29 August 2022*

In this tutorial, we dive into the generalization capabilities of quantum machine learning models.
For the example of a `Quantum Convolutional Neural Network (QCNN) <https://pennylane.ai/qml/glossary/qcnn.html>`_, we show how its generalization error behaves as a
function of the number of training samples. This demo is based on the paper
*"Generalization in quantum machine learning from few training data"*. by Caro et al. [#CaroGeneralization]_.

What is generalization in (Q)ML?
---------------------------------
When optimizing a machine learning model, be it classical or quantum, we aim to maximize its performance over the data
distribution of interest (e.g., images of cats and dogs). However, in practice, we are limited to a finite amount of
data, which is why it is necessary to reason about how our model performs on new, previously unseen data. The difference
between the model's performance on the true data distribution and the performance estimated from our training data is
called the *generalization error*, and it indicates how well the model has learned to generalize to unseen data.
Generalization can be seen as a manifestation of the bias-variance trade-off; models that
perfectly fit the training data admit a low bias at the cost of a higher variance, and hence typically perform poorly on unseen
test data. In the classical machine learning community, this trade-off has been extensively
studied and has led to optimization techniques that favour generalization, for example, by regularizing models via
their variance [#NamkoongVariance]_.
Below, we see a canoncial example of this trade-off, with a model having low bias, but high variance
and therefore high generalization error. The low variance model, on the other hand, has a higher 
bias but generalizes better.

.. figure:: /demonstrations/learning_few_data/overfitting.png
    :width: 65%
    :align: center



Let us now dive deeper into generalization properties of quantum machine learning (QML) models. We start by describing
the typical data processing pipeline of a QML model. A classical data input :math:`x` is first encoded in a quantum
state via a mapping :math:`x \mapsto \rho(x)`. This encoded state is then processed through a quantum
channel :math:`\rho(x) \mapsto \mathcal{E}_\alpha(\rho(x))` with learnable parameters :math:`\alpha`. Finally, a measurement is performed on the resulting state
to get the final prediction. Now, the goal is to minimize the expected loss over the data-generating distribution
:math:`P`, indicating how well our model performs on new data. Mathematically, for a loss function :math:`\ell`, the
expected loss, denoted by :math:`R`, is given by

.. math:: R(\alpha) = \mathbb{E}_{(x,y)\sim P}[\ell(\alpha;\,x,\,y)]

where :math:`x` are the features, :math:`y` are the labels, and :math:`P` is their joint distribution.
In practice, as the joint distribution :math:`P` is generally unknown, this quantity has to be 
estimated from a finite amount of data. Given a training set :math:`S = \{(x_i,\,y_i)\}_{i=1}^N` 
with :math:`N` samples, we estimate the performance of our QML model by calculating the 
average loss over the training set

.. math:: R_S(\alpha) = \frac{1}{N}\sum_{i=1}^N \ell(\alpha;\,x_i,\,y_i),

which is referred to as the training loss and is an unbiased estimate of :math:`R(\alpha)`. This is only a proxy
to the true quantity of interest :math:`R(\alpha)`, and their difference is called the generalization error

.. math:: \mathrm{gen}(\alpha) =  R(\alpha) - \hat{R}_S(\alpha),

which is the quantity that we explore in this tutorial. Keeping in mind the bias-variance trade-off, one would expect
that more complex models, i.e. models with a larger number of parameters, achieve a lower error on the training data
but a higher generalization error. Having more training data, on the other hand, leads to a better approximation of the
true expected loss and hence a lower generalization error. This intuition is made precise in Ref. [#CaroGeneralization]_, 
where it is shown that :math:`\mathrm{gen}(\alpha)` roughly scales as :math:`\mathcal{O}(\sqrt{T / N})`, where :math:`T`
is the number of parametrized gates and :math:`N` is the number of training samples.
"""

##############################################################################
# Generalization bounds for QML models
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# As hinted at earlier, we expect the generalization error to depend both on the richness of the model class, as well as
# on the amount of training data available. As a first result, the authors of Ref. [#CaroGeneralization]_ found that for
# a QML model with at most :math:`T` parametrized local quantum channels, the generalization error depends on :math:`T`
# and :math:`N` according to
#
# .. math:: \mathrm{gen}(\alpha) \sim \mathcal{O}\left(\sqrt{\frac{T\log T}{N}}\right).
#
# We see that this scaling is in line with our intuition that the generalization error scales inversely with the number
# of training samples and increases with the number of parametrized gates. However, as is the case for
# `quantum convolutional neural networks (QCNNs) <https://pennylane.ai/qml/glossary/qcnn.html>`_, it is possible to get a more fine-grained bound by including knowledge on the number of gates :math:`M` which have been reused (i.e. whose parameters are shared across wires). Naively, one could suspect that the generalization error scales as
# :math:`\tilde{\mathcal{O}}(\sqrt{MT/N})` by directly applying the above result (and where
# :math:`\tilde{\mathcal{O}}` includes logarithmic factors). However, the authors of Ref. [#CaroGeneralization]_ found
# that such models actually adhere to the better scaling
#
# .. math:: \mathrm{gen}(\alpha) \sim \mathcal{O}\left(\sqrt{\frac{T\log MT}{N}}\right).
#
# With this, we see that for QCNNs to have a generalization error :math:`\mathrm{gen}(\alpha)\leq\epsilon`, we need a
# training set of size :math:`N \sim T \log MT / \epsilon^2`. For the special case of QCNNs, we can explicitly connect
# the number of samples needed for good generalization to the system size :math:`n` since these models
# use :math:`\mathcal{O}(\log(n))` independently parametrized gates, each of which is used at most :math:`n` times [#CongQuantumCNN]_.
# Putting the pieces together, we find that a training set of size
#
# .. math::  N \sim \mathcal{O}(\mathrm{poly}(\log n))
#
# is sufficient for the generalization error to be bounded by :math:`\mathrm{gen}(\alpha) \leq \epsilon`.
# In the next part of this tutorial, we will illustrate this result by implementing a QCNN to classify different
# digits in the classical ``digits`` dataset. Before that, we set up our QCNN.

##############################################################################
# Quantum convolutional neural networks
# ------------------------------------
# Before we start building a QCNN, let us briefly review the idea of classical CNNs, which have shown
# tremendous success in tasks like image recognition, recommender systems, and sound classification, to name a few.
# For a more in-depth explanation of CNNs, we highly recommend `chapter 9 <https://www.deeplearningbook.org/contents/convnets.html>`_
# in [#DLBook]_.
# Classical CNNs are a family of neural networks which make use of convolutions and pooling operations to
# insert an inductive bias, favouring invariances to spatial transformations like translations, rotations, and scaling.
# A *convolutional layer* consists of a small kernel (a window) that sweeps over a 2D array representation of an image and extracts local
# information while sharing parameters across the spatial dimensions. In addition to the convolutional layers,
# one typically uses pooling layers to reduce the size of the input and to provide a mechanism for summarizing
# information from a neighbourhood of values in the input. On top of reducing dimensionality, these types of layers have the advantage
# of making the model more agnostic to certain transformations like scaling and rotations.
# These two types of layers are applied repeatedly in an alternating manner as shown in the figure below.
#
# .. figure:: /demonstrations/learning_few_data/cnn_pic.png
#     :width: 75%
#     :align: center
#       
#     A graphical representation of a CNN. Obtained using Ref. [#LeNailNNSVG]_.
#
# We want to build something similar for a quantum circuit. First, we import the necessary
# libraries we will need in this demo and set a random seed for reproducibility:
























##############################################################################
# To construct a convolutional and pooling layer in a quantum circuit, we will
# follow the QCNN construction proposed in [#CongQuantumCNN]_. The former layer
# will extract local correlations, while the latter allows reducing the dimensionality
# of the feature vector. In a quantum circuit, the convolutional layer, consisting of a kernel swept
# along the entire image, is a two-qubit unitary that correlates neighbouring
# qubits.  As for the pooling layer, we will use a conditioned single-qubit unitary that depends
# on the measurement of a neighboring qubit. Finally, we use a *dense layer* that entangles all
# qubits of the final state using an all-to-all unitary gate as shown in the figure below.
#
# .. figure:: /demonstrations/learning_few_data/qcnn-architecture.png
#     :width: 75%
#     :align: center
#
#     QCNN architecture. Taken from Ref. [#CongQuantumCNN]_.
#
# Breaking down the layers
# --------------------------
#
# The convolutional layer should have the weights of the two-qubit unitary as an input, which are
# updated at every training step.  In PennyLane, we model this arbitrary two-qubit unitary
# with a particular sequence of gates: two single-qubit  :class:`~.pennylane.U3` gates (parametrized by three
# parameters, each), three Ising interactions between both qubits (each interaction is
# parametrized by one parameter), and two additional :class:`~.pennylane.U3` gates on each of the two
# qubits. 
























##############################################################################
# The pooling layer's inputs are the weights of the single-qubit conditional unitaries, which in
# this case are :class:`~.pennylane.U3` gates. Then, we apply these conditional measurements to half of the
# unmeasured wires, reducing our system size by a factor of 2.

















##############################################################################
# We can construct a QCNN by combining both layers and using an arbitrary unitary to model
# a dense layer. It will take a set of features — the image — as input, encode these features using
# an embedding map, apply rounds of convolutional and pooling layers, and eventually output the
# desired measurement statistics of the circuit.



















































##############################################################################
# In the problem we will address, we need to encode 64 features
# in our quantum state. Thus, we require six qubits (:math:`2^6 = 64`) to encode
# each feature value in the amplitude of each computational basis state.
#
# Training the QCNN on the digits dataset
# ---------------------------------------
# In this demo, we are going to classify the digits ``0`` and ``1`` from the classical ``digits`` dataset.
# Each hand-written digit image is represented as an :math:`8 \times 8` array of pixels as shown below:


















##############################################################################
# For convenience, we create a ``load_digits_data`` function that will make random training and
# testing sets from the ``digits`` dataset from ``sklearn.dataset``:































##############################################################################
# To optimize the weights of our variational model, we define the cost and accuracy functions
# to train and quantify the performance on the classification task of the previously described QCNN:



































##############################################################################
# We are going to perform the classification for training sets with different values of :math:`N`. Therefore, we
# define the classification procedure once and then perform it for different datasets.
# Finally, we update the weights using the :class:`pennylane.AdamOptimizer` and use these updated weights to
# calculate the cost and accuracy on the testing and training set:






























































##############################################################################
# .. note::
#
#     There are some small intricacies for speeding up this code that are worth mentioning. We are using ``jax`` for our training
#     because it allows for `just-in-time <https://jax.readthedocs.io/en/latest/jax-101/02-jitting.html>`_ (``jit``) compilation. A function decorated with ``@jax.jit`` will be compiled upon its first execution
#     and cached for future executions. This means the first execution will take longer, but all subsequent executions are substantially faster.
#     Further, we use ``jax.vmap`` to vectorize the execution of the QCNN over all input states, as opposed to looping through the training and test set at every execution.

##############################################################################
# Training for different training set sizes yields different accuracies, as seen below. As we increase the training data size, the overall test accuracy,
# a proxy for the models' generalization capabilities, increases:




















# run training for multiple sizes





##############################################################################
# Finally, we plot the loss and accuracy for both the training and testing set
# for all training epochs, and compare the test and train accuracy of the model:

# aggregate dataframe









# plot losses and accuracies

















# format loss plot





# format generalization error plot








# format loss plot



















##############################################################################
# ------------
#
#
# The key takeaway of this work is that some quantum learning 
# models can achieve high-fidelity predictions using a few training data points. 
# We implemented a model known as the quantum convolutional neural network (QCNN) using PennyLane 
# for a binary classification task. Using six qubits, we have trained the QCNN to distinguish 
# between handwritten digits of :math:`0`'s and :math:`1`'s. With :math:`80` samples, we have 
# achieved a model with accuracy greater than :math:`97\%` in :math:`100` training epochs. 
# Furthermore, we have compared the test and train accuracy of this model for a different number of 
# training samples and found the scaling of the generalization error agrees with the theoretical 
# bounds obtained in [#CaroGeneralization]_.
# 
# 
# References
# ----------
#
# .. [#CaroGeneralization]
#
#     Matthias C. Caro, Hsin-Yuan Huang, M. Cerezo, Kunal Sharma, Andrew Sornborger, Lukasz Cincio, Patrick J. Coles.
#     "Generalization in quantum machine learning from few training data"
#     `arxiv:2111.05292 <https://arxiv.org/abs/2111.05292>`__, 2021.
#
# .. [#DLBook]
#
#     Ian Goodfellow, Yoshua Bengio and Aaron Courville.
#     `"Deep Learning"2 <http://www.deeplearningbook.org>`__, 2016.
#
# .. [#NamkoongVariance]
#
#     Hongseok Namkoong and John C. Duchi.
#     "Variance-based regularization with convex objectives."
#     `Advances in Neural Information Processing Systems
#     <https://proceedings.neurips.cc/paper/2017/file/5a142a55461d5fef016acfb927fee0bd-Paper.pdf>`__, 2017.
#
# .. [#CongQuantumCNN]
#
#     Iris Cong, Soonwon Choi, Mikhail D. Lukin.
#     "Quantum Convolutional Neural Networks"
#     `arxiv:1810.03787 <https://arxiv.org/abs/1810.03787>`__, 2018.
# 
# .. [#LeNailNNSVG]
#
#     Alexander LeNail.
#     "NN-SVG: Publication-Ready Neural Network Architecture Schematics"
#     `Journal of Open Source Software <https://doi.org/10.21105/joss.00747>`__, 2019.
#
#
# About the authors
# -----------------
# .. include:: ../_static/authors/korbinian_kottmann.txt
#
# .. include:: ../_static/authors/luis_mantilla_calderon.txt
#
# .. include:: ../_static/authors/maurice_weber.txt
