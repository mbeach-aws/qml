"""
.. _kernel_based_training:

.. role:: html(raw)
   :format: html

Kernel-based training of quantum models with scikit-learn
=========================================================

.. meta::
    :property="og:description": Train a quantum machine learning model based on the idea of quantum kernels.
    :property="og:image": https://pennylane.ai/qml/_images/kernel_based_scaling.png

.. related::

    tutorial_variational_classifier Variational classifier

*Author: Maria Schuld — Posted: 03 February 2021. Last updated: 3 February 2021.*

Over the last few years, quantum machine learning research has provided a lot of insights on
how we can understand and train quantum circuits as machine learning models.
While many connections to neural networks have been made, it becomes increasingly clear that
their mathematical foundation is intimately related to so-called *kernel methods*, the most famous
of which is the `support vector machine (SVM) <https://en.wikipedia.org/wiki/Support-vector_machine>`__
(see for example `Schuld and Killoran (2018) <https://arxiv.org/abs/1803.07128>`__,
`Havlicek et al. (2018) <https://arxiv.org/abs/1804.11326>`__,
`Liu et al. (2020) <https://arxiv.org/abs/2010.02174>`__,
`Huang et al. (2020) <https://arxiv.org/pdf/2011.01938>`__,
and, for a systematic summary which we will follow here,
`Schuld (2021) <https://arxiv.org/abs/2101.11020>`__).

The link between quantum models and kernel methods has important practical implications:
we can replace the common `variational approach <https://pennylane.ai/qml/glossary/variational_circuit.html>`__
to quantum machine learning with a classical kernel method where the kernel—a small building block
of the overall algorithm—is computed by a quantum device. In many situations there are
guarantees that we get better or at least equally good results.

This demonstration explores how kernel-based training compares with
`variational training <https://pennylane.ai/qml/demos/tutorial_variational_classifier.html>`__ in terms of the number of quantum
circuits that have to be evaluated. For this we train a quantum machine
learning model with a kernel-based approach using a combination of PennyLane
and the `scikit-learn <https://scikit-learn.org/>`__ machine
learning library. We compare this strategy with a variational
quantum circuit trained via stochastic gradient descent using
`PyTorch <https://pennylane.readthedocs.io/en/stable/introduction/interfaces/torch.html>`__.

We will see that in a typical small-scale example, kernel-based training requires only a fraction of the number of
quantum circuit evaluations used by variational circuit training, while each
evaluation runs a much shorter circuit.
In general, the relative efficiency of kernel-based methods compared to variational circuits
depends on the number of parameters used in the variational model.

.. figure::  ../demonstrations/kernel_based_training/scaling.png
       :align: center
       :scale: 100%
       :alt: Scaling of kernel-based vs. variational learning

If the number of variational parameters remains small, e.g., there is a square-root-like scaling with the number
of data samples (green line), variational circuits are almost as efficient as neural networks (blue line),
and require much fewer circuit evaluations
than the quadratic scaling of kernel methods (red line).
However, with current hardware-compatible training strategies,
kernel methods scale much better than variational circuits that require a number of parameters of the
order of the training set size (orange line).

In conclusion, **for quantum machine learning applications with many parameters, kernel-based training can be a great
alternative to the variational approach to quantum machine learning**.

After working through this demo, you will:

* be able to use a support vector machine with a quantum kernel computed with PennyLane, and

* be able to compare the scaling of quantum circuit evaluations required in kernel-based versus
  variational training.


"""

######################################################################
# Background
# ----------
#
# Let us consider a *quantum model* of the form
#
# .. math:: f(x) = \langle \phi(x) | \mathcal{M} | \phi(x)\rangle,
#
# where :math:`| \phi(x)\rangle` is prepared
# by a fixed `embedding
# circuit <https://pennylane.ai/qml/glossary/quantum_embedding.html>`__ that
# encodes data inputs :math:`x`,
# and :math:`\mathcal{M}` is an arbitrary observable. This model includes variational
# quantum machine learning models, since the observable can
# effectively be implemented by a simple measurement that is preceded by a
# variational circuit:
#
#
# .. figure:: ../demonstrations/kernel_based_training/quantum_model.png
#       :align: center
#       :scale: 20%
#       :alt: quantum-model
#
# |
#
# For example, applying a circuit :math:`G(\theta)` and then
# measuring the Pauli-Z observable :math:`\sigma^0_z` of the first qubit
# implements the trainable measurement
# :math:`\mathcal{M}(\theta) = G^{\dagger}(\theta) \sigma^0_z G(\theta)`.
#
# The main practical consequence of approaching quantum machine learning with a
# kernel approach is that instead of training :math:`f` variationally,
# we can often train an equivalent classical kernel method with a kernel executed on a
# quantum device. This *quantum kernel*
# is given by the mutual overlap of two data-encoding quantum states,
#
# .. math::  \kappa(x, x') = | \langle \phi(x') | \phi(x)\rangle|^2.
#
# Kernel-based training therefore bypasses the processing and measurement
# parts of common variational circuits, and only depends on the
# data encoding.
#
# If the loss function :math:`L` is the `hinge
# loss <https://en.wikipedia.org/wiki/Hinge_loss>`__, the kernel method
# corresponds to a standard `support vector
# machine <https://en.wikipedia.org/wiki/Support-vector_machine>`__ (SVM)
# in the sense of a maximum-margin classifier. Other convex loss functions
# lead to more general variations of support vector machines.
#
# .. note::
#
#    More precisely, we can replace variational with kernel-based
#    training if the optimisation
#    problem can be written as minimizing a cost of the form
#
#    .. math::  \min_f  \lambda\;  \mathrm{tr}\{\mathcal{M}^2\} + \frac{1}{M}\sum_{m=1}^M L(f(x^m), y^m),
#
#    which is a regularized empirical risk with training data samples :math:`(x^m, y^m)_{m=1\dots M}`,
#    regularization strength :math:`\lambda \in \mathbb{R}`, and loss function :math:`L`.
#
#    Theory predicts that kernel-based training will always find better or equally good
#    minima of this risk. However, to show this here we would have
#    to either regularize the variational training by the trace of the squared observable, or switch off
#    regularization in the classical SVM, which removes a lot of its strength. The kernel-based and the variational
#    training in this demonstration therefore optimize slightly different cost
#    functions, and it is out of our scope to establish whether one training method finds a better minimum than
#    the other.
#


######################################################################
# Kernel-based training
# ---------------------
#
# First, we will turn to kernel-based training of quantum models.
# As stated above, an example implementation is a standard support vector
# machine with a kernel computed by a quantum circuit.
#


######################################################################
# We begin by importing all sorts of useful methods:
#




















######################################################################
# The second step is to define a data set. Since the performance
# of the models is not the focus of this demo, we can just use
# the first two classes of the famous `Iris data set <https://en.wikipedia.org/wiki/Iris_flower_data_set>`__.
# Dating back to as far as 1936,
# this toy data set consists of 100 samples of four features each,
# and gives rise to a very simple classification problem.
#



# pick inputs and labels from the first two classes only,
# corresponding to the first 100 samples



# scaling the inputs is important since the embedding we use is periodic



# scaling the labels to -1, 1 is important for the SVM and the
# definition of a hinge loss





######################################################################
# We use the `angle-embedding
# template <https://pennylane.readthedocs.io/en/stable/code/api/pennylane.templates.embeddings.AngleEmbedding.html>`__
# which needs as many qubits as there are features:
#





######################################################################
# To implement the kernel we could prepare the two states :math:`| \phi(x) \rangle`, :math:`| \phi(x') \rangle`
# on different sets of qubits with angle-embedding routines :math:`S(x), S(x')`,
# and measure their overlap with a small routine called a `SWAP test <https://en.wikipedia.org/wiki/Swap_test>`__.
#
# However, we need only half the number of qubits if we prepare
# :math:`| \phi(x)\rangle` and then apply the inverse embedding
# with :math:`x'` on the same qubits. We then measure the projector onto
# the initial state :math:`|0..0\rangle \langle 0..0|`.
#
# .. figure:: ../demonstrations/kernel_based_training/kernel_circuit.png
#       :align: center
#       :scale: 80%
#       :alt: Kernel evaluation circuit
#
# To verify that this gives us the kernel:
#
# .. math::
#
#      \begin{align*}
#          \langle 0..0 |S(x') S(x)^{\dagger} \mathcal{M} S(x')^{\dagger} S(x)  | 0..0\rangle &= \langle 0..0 |S(x') S(x)^{\dagger} |0..0\rangle \langle 0..0| S(x')^{\dagger} S(x)  | 0..0\rangle  \\
#          &= |\langle 0..0| S(x')^{\dagger} S(x)  | 0..0\rangle |^2\\
#          &= | \langle \phi(x') | \phi(x)\rangle|^2 \\
#          &= \kappa(x, x').
#      \end{align*}
#
# Note that a projector :math:`|0..0 \rangle \langle 0..0|` can be constructed
# using the ``qml.Hermitian`` observable in PennyLane.
#
# Altogether, we use the following quantum node as a *quantum kernel
# evaluator*:
#














######################################################################
# A good sanity check is whether evaluating the kernel of a data point and
# itself returns 1:
#




######################################################################
# The way an SVM with a custom kernel is implemented in scikit-learn
# requires us to pass a function that computes a matrix of kernel
# evaluations for samples in two different datasets A, B. If A=B,
# this is the `Gram matrix <https://en.wikipedia.org/wiki/Gramian_matrix>`__.
#








######################################################################
# Training the SVM optimizes internal parameters that basically
# weigh kernel functions.
# It is a breeze in scikit-learn, which is designed
# as a high-level machine learning library:
#




######################################################################
# Let’s compute the accuracy on the test set.
#





######################################################################
# The SVM predicted all test points correctly.
# How many times was the quantum device evaluated?
#




######################################################################
# This number can be derived as follows: For :math:`M` training samples,
# the SVM must construct the :math:`M \times M` dimensional kernel gram
# matrix for training. To classify :math:`M_{\rm pred}` new samples, the
# SVM needs to evaluate the kernel at most :math:`M_{\rm pred}M` times to get the
# pairwise distances between training vectors and test samples.
#
# .. note::
#
#     Depending on the implementation of the SVM, only :math:`S \leq M_{\rm pred}`
#     *support vectors* are needed.
#
# Let us formulate this as a function, which can be used at the end of the demo
# to construct the scaling plot shown in the introduction.
#















######################################################################
# With :math:`M = 75` and :math:`M_{\rm pred} = 25`, the number of kernel evaluations
# can therefore be estimated as:
#




######################################################################
# The single additional evaluation can be attributed to evaluating the kernel once above
# as a sanity check.
#

######################################################################
# A similar example using variational training
# --------------------------------------------
#


######################################################################
# Using the variational principle of training, we can propose an *ansatz*
# for the variational circuit and train it directly. By
# increasing the number of layers of the ansatz, its expressivity
# increases. Depending on the ansatz, we may only
# search through a subspace of all measurements for the best
# candidate.
#
# Remember from above, the variational training does not optimize
# *exactly* the same cost as the SVM, but we try to match them as closely
# as possible. For this we use a bias term in the quantum model, and train
# on the hinge loss.
#
# We also explicitly use the `parameter-shift <https://pennylane.ai/qml/glossary/parameter_shift.html>`__
# differentiation method in the quantum node, since this is a method which works on hardware as well.
# While ``diff_method='backprop'`` or ``diff_method='adjoint'`` would reduce the number of
# circuit evaluations significantly, they are based on tricks that are only suitable for simulators,
# and can therefore not scale to more than a few dozen qubits.
#




























######################################################################
# We now summarize the usual training and prediction steps into two
# functions similar to scikit-learn's ``fit()`` and ``predict()``. While
# it feels cumbersome compared to the one-liner used to train the kernel method,
# PennyLane—like other differentiable programming libraries—provides a lot more
# control over the particulars of training.
#
# In our case, most of the work is to convert between numpy and torch,
# which we need for the differentiable ``relu`` function used in the hinge loss.
#





























































######################################################################
# Let’s train the variational model and see how well we are doing on the
# test set.
#
















######################################################################
# The variational circuit has a slightly lower
# accuracy than the SVM—but this depends very much on the training settings
# we used. Different random parameter initializations, more layers, or more steps may indeed get
# perfect test accuracy.
#
# How often was the device executed?
#




######################################################################
# That is a lot more than the kernel method took!
#
# Let’s try to understand this value. In each optimization step, the variational
# circuit needs to compute the partial derivative of all
# trainable parameters for each sample in a batch. Using parameter-shift
# rules, we require roughly two circuit
# evaluations per partial derivative. Prediction uses only one circuit
# evaluation per sample.
#
# We can formulate this as another function that will be used in the scaling plot below.
#















######################################################################
# This estimates the circuit evaluations in variational training as:
#











######################################################################
# The estimate is a bit higher because it does not account for some optimizations
# that PennyLane performs under the hood.
#
# It is important to note that while they are trained in a similar manner,
# the number of variational circuit evaluations differs from the number of
# neural network model evaluations in classical machine learning, which would be given by:
#













######################################################################
# In each step of neural network training, and due to the clever implementations of automatic differentiation,
# the backpropagation algorithm can compute a
# gradient for all parameters in (more-or-less) a single run.
# For all we know at this stage, the no-cloning principle prevents variational circuits from using these tricks,
# which leads to ``n_training`` in ``circuit_evals_variational`` depending on the number of parameters, but not in
# ``model_evals_nn``.
#
# For the same example as used here, a neural network would therefore
# have far fewer model evaluations than both variational and kernel-based training:
#










######################################################################
# Which method scales best?
# -------------------------
#


######################################################################
# The answer to this question depends on how the variational model
# is set up, and we need to make a few assumptions:
#
# 1. Even if we use single-batch stochastic gradient descent, in which every training step uses
#    exactly one training sample, we would want to see every training sample at least once on average.
#    Therefore, the number of steps should scale at least linearly with the number of training data samples.
#
# 2. Modern neural networks often have many more parameters than training
#    samples. But we do not know yet whether variational circuits really need that many parameters as well.
#    We will therefore use two cases for comparison:
#
#    2a) the number of parameters grows linearly with the training data, or ``n_params = M``,
#
#    2b) the number of parameters saturates at some point, which we model by setting ``n_params = sqrt(M)``.
#
# Note that compared to the example above with 75 training samples and 24 parameters, a) overestimates the number of evaluations, while b)
# underestimates it.
#


######################################################################
# This is how the three methods compare:
#









































######################################################################
# This is the plot we saw at the beginning.
# With current hardware-compatible training methods, whether kernel-based training
# requires more or fewer quantum circuit evaluations
# than variational training depends on how many parameters the latter needs.
# If variational circuits turn out to be as parameter-hungry as neural networks,
# kernel-based training will outperform them for common machine learning tasks. However,
# if variational learning only turns out to require few parameters (or if more efficient training methods are found),
# variational circuits could in principle match the linear scaling of neural networks trained with backpropagation.
#
# The practical take-away from this demo is that unless your variational circuit has significantly fewer
# parameters than training data, kernel methods could be a much faster alternative!
#
# Finally, it is important to note that fault-tolerant quantum computers may change the picture
# for both quantum and classical machine learning.
# As mentioned in `Schuld (2021) <https://arxiv.org/abs/2101.11020>`__,
# early results from the quantum machine learning literature show that
# larger quantum computers will most likely enable us to reduce
# the quadratic scaling of kernel methods to linear scaling, which may make classical as well as quantum kernel methods a
# strong alternative to neural networks for big data processing one day.
#

##############################################################################
# About the author
# ----------------
# .. include:: ../_static/authors/maria_schuld.txt