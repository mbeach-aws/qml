r"""Estimating observables with classical shadows in the Pauli basis
====================================================================

.. meta::
    :property="og:description": Classical shadows in the Pauli basis
    :property="og:image": https://pennylane.ai/qml/_images/pauli_shadows.jpg


.. related::

    tutorial_classical_shadows Introduction to classic shadows
    tutorial_ml_classical_shadows Classic shadows in machine learning

*Author: Korbinian Kottmann — Posted: 07 October 2022. Last updated: 11 October 2022.*

We briefly introduce the classical shadow formalism in the Pauli basis and showcase PennyLane's new implementation of it.
Classical shadows are sometimes believed to provide advantages in quantum resources to simultaneously estimate multiple observables.
We demystify this misconception and perform fair comparisons between classical shadow measurements and simultaneously measuring
qubit-wise-commuting observable groups.

Classical shadow theory
-----------------------

A `classical shadow` is a classical description of a quantum state that is capable of reproducing expectation values of local Pauli observables, see [#Huang2020]_.
We briefly go through their theory here, and note the two additional demos in :doc:`tutorial_classical_shadows` and :doc:`tutorial_ml_classical_shadows`.

We are here focussing on the case where measurements are performed in the Pauli basis.
The idea of classical shadows is to measure each qubit in a random Pauli basis.
While doing so, one keeps track of the performed measurement (its ``recipes``) in form
of integers ``[0, 1, 2]`` corresponding to the measurement bases ``[X, Y, Z]``, respectively.
At the same time, the measurement outcome (its ``bits``) are recorded, where ``[0, 1]``
corresponds to the eigenvalues ``[1, -1]``, respectively.

We record :math:`T` of such measurements, and for the :math:`t`-th measurement, we can reconstruct the ``local_snapshot`` for :math:`n` qubits via

.. math:: \rho^{(t)} = \bigotimes_{i=1}^{n} 3 U^\dagger_i |b^{(t)}_i \rangle \langle b^{(t)}_i | U_i - \mathbb{I},

where :math:`U_i` is the diagonalizing rotation for the respective Pauli basis (e.g. :math:`U_i=H` for measurement in :math:`X`) for qubit `i`.
:math:`|b^{(t)}_i\rangle = (1 - b^{(t)}_i, b^{(t)}_i)` is the corresponding computational basis state given by the output bit :math:`b^{(t)}_i \in \{0, 1\}`.

From these local snapshots, one can compute expectation values of q-local Pauli strings, where locality refers to the number of non-Identity operators.
The expectation value of any Pauli string :math:`\bigotimes_iO_i` with :math:`O_i \in \{X, Y, Z, \mathbb{I}\}` can be estimated
by computing 

.. math:: \Big\langle \bigotimes_iO_i \Big\rangle = \frac{1}{T} \sum_{t=1}^T \text{tr}\left[ \rho^{(t)} \left(\bigotimes_i O_i\right) \right].

Error bounds given by the number of measurements :math:`T = \mathcal{O}\left( \log(M) 4^q/\varepsilon^2 \right)` guarantee that sufficiently many correct measurements
were performed to estimate :math:`M` different observables up to additive error :math:`\varepsilon`. This :math:`\log(M)` factor may lead one to think that with classical shadows one can
`magically` estimate multiple observables at a lower cost than with direct measurement. We resolve this misconception in the following section.


Unraveling the mystery
~~~~~~~~~~~~~~~~~~~~~~
Using algebraic properties of Pauli operators, we show how to exactly compute the above expression from just the ``bits`` and ``recipes``
without explicitly reconstructing any snapshots. This gives us insights to what is happening under the hood and how the ``T`` measuerements are used to estimate the observable.

Let us start by looking at individual snapshot expectation values
:math:`\langle \bigotimes_iO_i \rangle ^{(t)} = \text{tr}\left[\rho^{(t)} \left(\bigotimes_iO_i \right)\right]`.
First, we convince ourselves of the identity

.. math:: U_i^\dagger |b^{(t)}_i\rangle \langle b^{(t)}_i| U_i = \frac{1}{2}\left((1-2b^{(t)}_i) P_i + \mathbb{I}\right),

where :math:`P_i \in \{X, Y, Z\}` is the Pauli operator corresponding to :math:`U_i` (note that in this case :math:`P_i` is never the identity). 
The snapshot expectation value then reduces to

.. math:: \Big\langle\bigotimes_iO_i\Big\rangle^{(t)} = \prod_{i=1}^n \text{tr}\left[\frac{3}{2}(1-2b^{(t)}_i)P_i O_i + \frac{1}{2}O_i\right].

For that trace we find three different cases.
The cases where :math:`O_i=\mathbb{I}` yield a trivial factor :math:`1` to the product.
The full product is always zero if any of the non-trivial :math:`O_i` do not match :math:`P_i`. So in total, `only` in the case that all :math:`q` Pauli operators match, we find

.. math:: \Big\langle\bigotimes_iO_i\Big\rangle^{(t)} = 3^q \prod_{\text{i non-trivial}}(1-2b^{(t)}_i).

This implies that in order to compute the expectation value of a Pauli string

.. math:: \Big\langle\bigotimes_iO_i\Big\rangle = \frac{1}{\tilde{T}} \sum_{\tilde{t}} \prod_{\text{i non-trivial}}(1-2b^{(t)}_i)

we simply need average over the product of :math:`1 - 2b^{(t)}_i = \pm 1` for those  :math:`\tilde{T}` snapshots where the measurement recipe matches the observable,
indicated by the special index :math:`\tilde{t}` for the matching measurements. Note that the probability of a match is :math:`1/3^q` such that we have
:math:`\tilde{T} \approx T / 3^q` on average.

This implies that computing expectation values with classical shadows comes down to picking the specific subset of snapshots where those specific observables
were already measured and discarding the remaining. If the desired observables are known prior to the measurement,
one is thus advised to directly perform those measurements.
This was referred to as `derandomization` by the authors in a follow-up paper [#Huang2021]_.


We will later compare the naive classical shadow approach to directly measuring the desired observables and make use of simultaneously
measuring qubit-wise-commuting observables. Before that, let us demonstrate how to perform classical shadow measurements in a differentiable manner in PennyLane.

PennyLane implementation
------------------------

There are two ways of computing expectation values with classical shadows in PennyLane. The first is to return :func:`qml.shadow_expval <pennylane.shadow_expval>` directly from the qnode.
This has the advantage that it preserves the typical PennyLane syntax *and* is differentiable.
"""




















##############################################################################
# Compute expectation values and derivatives thereof in the common way in PennyLane.



##############################################################################
# Each call of :func:`qml.shadow_expval <pennylane.shadow_expval>` performs the number of shots dictated by the device.
# So to avoid unnecessary device executions you can provide a list of observables to :func:`qml.shadow_expval <pennylane.shadow_expval>`.





##############################################################################
# Alternatively, you can compute expectation values by first performing the shadow measurement and then perform classical post-processing using the :class:`~.pennylane.ClassicalShadow`
# class methods.













##############################################################################
# After recording these ``T=1000`` quantum measurements, we can post-process the results to arbitrary local expectation values of Pauli strings.
# For example, we can compute the expectation value of a Pauli string



##############################################################################
# or of a Hamiltonian:




##############################################################################
# This way of computing expectation values is not automatically differentiable in PennyLane though.



##############################################################################
# Comparing quantum resources with conventional measurement methods 
# -----------------------------------------------------------------
# 
# The goal of the following section is to compare estimation accuracy for a given number of quantum executions with more conventional methods
# like simultaneously measuring qubit-wise-commuting (qwc) groups, see :doc:`tutorial_measurement_optimize`. We are going to look at three different cases: The two extreme scenarios of measuring one single
# and `all` q-local Pauli strings, as well as the more realistic scenario of measuring a molecular Hamiltonian. We find that for a fix budget of measurements, one is
# almost never advised to use classical shadows for estimating expectation values.
# 
# Measuring one single observable
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# We start with the case of one single measurement. From the analysis above it should be quite clear that in the case of random Pauli measurement in the classical shadows
# formalism, a lot of quantum resources are wasted as all the measurements that do not match the observable are discarded. This is certainly not what classical shadows were intended for
# in the first place, but it helps to stress the point of wasted measurements.
# 
# We start by fixing a circuit and an observable, for which we compute the exact result for infinite shots.


























##############################################################################
# We now compare estimating the observable with classical shadows vs the canonical estimation.




































##############################################################################
#
# Unsurprisingly, the deviation is consistently smaller by directly measuring the observable since we are not discarding any measurement results.

##############################################################################
# All q-local observables
# ~~~~~~~~~~~~~~~~~~~~~~~
# For the case of measuring `all` q-local Pauli strings we expect both strategies to yield more or less the same results.
# In this extreme case, no measurements are discarded in the classical shadow protocol.
# Let us put that to test. First, we generate a list of all q-local observables for n qubits.







# create all combination of q entries of range(n)















##############################################################################
# We now group these into qubit-wise-commuting (qwc) groups using :func:`~pennylane.pauli.group_observables` to learn the number of
# groups. We need this number to make a fair comparison with classical shadows as we allow for only ``T/n_groups`` shots per group, such that
# the total number of shots is the same as for the classical shadow execution. We again compare both approaches.







































































##############################################################################
# 
# We see that as expected the performance is more or less the same since no quantum measurements are discarded for the shadows in this case.
# Depending on the chosen random seed there are quantitative variations to this image, but the overall qualitative result remains the same.
#
# Molecular Hamiltonians
# ~~~~~~~~~~~~~~~~~~~~~~
# We now look at the more realistic case of measuring a molecular Hamiltonian. We tak :math:`\text{H}_2\text{O}` as an example. 
# You can find more details on this Hamiltonian in :doc:`tutorial_quantum_chemistry`.
# We start by building the Hamiltonian and enforcing qwc groups by setting ``grouping_type='qwc'``.

























##############################################################################
# We use a pre-prepared Ansatz that approximates the :math:`\text{H}_2\text{O}` ground state for the given geometry. You can construct this Ansatz by running VQE, see :doc:`tutorial_vqe`.
# We ran this once on an ideal simulator to get the exact result of the energy for the given Ansatz.





















##############################################################################
# We again follow the same simple strategy of giving each group the same number of shots ``T/n_groups`` for ``T`` total shots.



















































##############################################################################
# For this realistic example, one is clearly better advised to directly compute the expectation values
# and not waste precious quantum resources on unused measurements in the classical shadow protocol.



##############################################################################
#
# Conclusion
# ----------
# Overall, we saw that classical shadows always waste unused quantum resources for measurements that are not used, except some extreme cases.
# For the rare case that the observables that are to be determined are not known before the measurement, classical shadows may prove advantageous.
# 
# We have been using a relatively simple approach to qwc grouping, as :func:`~pennylane.pauli.group_observables`
# is based on the largest first (LF) heuristic (see :func:`~pennylane.pauli.graph_colouring.largest_first`).
# There has been intensive research in recent years on optimizing qwc measurement schemes.
# Similarily, it has been realized by the original authors that the randomized shadow protocol can be improved by what they call derandomization [#Huang2021]_.
# Currently, it seems advanced grouping algorithms are still the preferred choice, as is illustrated and discused in [#Yen]_.
# 
#
#
# References
# ----------
#
# .. [#Huang2020]
#
#     Hsin-Yuan Huang, Richard Kueng, John Preskill
#     "Predicting Many Properties of a Quantum System from Very Few Measurements."
#     `arXiv:2002.08953 <https://arxiv.org/abs/2002.08953>`__, 2020.
#
# .. [#Huang2021]
#
#     Hsin-Yuan Huang, Richard Kueng, John Preskill
#     "Efficient estimation of Pauli observables by derandomization."
#     `arXiv:2103.07510 <https://arxiv.org/abs/2103.07510>`__, 2021.
#
# .. [#Yen] 
# 
#     Tzu-Ching Yen, Aadithya Ganeshram, Artur F. Izmaylov
#     "Deterministic improvements of quantum measurements with grouping of compatible operators, non-local transformations, and covariance estimates."
#     `arXiv:2201.01471 <https://arxiv.org/abs/2201.01471>`__, 2022.

##############################################################################
# About the author
# ----------------
# .. include:: ../_static/authors/korbinian_kottmann.txt
